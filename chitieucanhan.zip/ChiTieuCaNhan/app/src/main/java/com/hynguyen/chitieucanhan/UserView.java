package com.hynguyen.chitieucanhan;



public interface UserView {
    void OnLengthEmail();

    void OnValidEmail();

    void OnPass();

    void OnSucess();

    void OnAuthEmail();

    void OnFail();

    void OnPassNotSame();
}
