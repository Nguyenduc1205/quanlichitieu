package com.hynguyen.chitieucanhan;



public interface IUSER {
    void OnLengthEmail();

    void OnValidEmail();

    void Onpass();

    void OnSucess();

    void OnAuthEmail();

    void OnFail();

    void OnpassNotSame();
}
